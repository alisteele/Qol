include_recipe 'test::config'
include_recipe 'chef-client::service'
include_recipe 'chef-client::delete_validation'
