package librarySystemUpdates;

import java.util.Scanner;


/**
 * Library system 
 * @author Aidan McGowan
 *
 */
public class LibraryDesk {
	
	/**
	 * The number of books in the library
	 */
	private static int BOOKS_MAX = 5;

	/**
	 * Var to hold the list of book
	 */
	public static Book[] books = new Book[BOOKS_MAX];
	
	/**
	 * Used to read in user values
	 */
	public static Scanner scanner = new Scanner(System.in);
	
	/**
	 * Start point for the Library system app
	 * @param args
	 */
	public static void main(String[] args) {
		try{
			// populate the book list
			populateBooksList();
			boolean exit= false;
			int option=0;
			do {
				// draw menu and get user's option
				option = drawMenu();

				switch (option){
				case 1 :
					listAllBooks();
					break;
				case 2 :
					searchByAuthor();
					break;
				case 3 :
					loanBook();
					break;
				case 4 :
					returnBook();
					break;
				case 5 :
					viewAllOnloan();
					break;
				case 6 :
					viewAllNotOnloan();
					break;
				case 7 :
					searchByGenre();
					break;
				case 8 :
					searchByRating();
					break;
				case 9 : System.out.println("System exiting.");
					exit=true;
					break;
				default : 
					System.out.println("Sorry try that again");
				}
			} while (!exit);
		} catch (Exception ex){
			System.out.println("Sorry. System error. Exiting");
		} finally {
			scanner.close();
		}
	}
	
	
	/**
	 * View all onloan books
	 */
	private static void viewAllOnloan() {
		int booksFound=0;
		for (Book b : books){
			if (b.isOnLoan()){
				booksFound++;
				System.out.printf("%-30s %-20s %-10d  %-10b \n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan());
			}
		}
		System.out.println("Number of onloan books found "+booksFound);
		
	}
	
	

	/**
	 * View all  books not on loan
	 */
	private static void viewAllNotOnloan() {
		int booksFound=0;
		for (Book b : books){
			if (!b.isOnLoan()){
				booksFound++;
				System.out.printf("%-30s %-20s %-10d  %-10b \n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan());
			}
		}
		System.out.println("Number of books not on loan found "+booksFound);
		
	}

	/**
	 * Populates the books list in the library
	 */
	public static void populateBooksList(){
		// create the default book list
		Book book1 = new Book("Catch 22","Heller",1,"Comedy",5);
		Book book2 = new Book("The Hobbit","Tolkien",2,"Adventure",4);
		Book book3 = new Book("Gullivers Travels","Swift",3,"Satire",5);
		Book book4 = new Book("Moby Dick","Melville",4,"Fishy tale",1);
		Book book5 = new Book("The Lord of the Rings","Tolkien",5,"Adventure",3);
		
		// add to the books array
		books[0] = book1;
		books[1] = book2;
		books[2] = book3;
		books[3] = book4;
		books[4] = book5;
	}
	
	/**
	 * Draws menu and returns the user's option
	 * @return the user's option from the menu
	 */
	public static int drawMenu(){
		int option =0;
		
		try {
			System.out.println("\n\nLibrary System______________");
			System.out.println("1. List all books");
			System.out.println("2. Search by Author");
			System.out.println("3. Loan book");
			System.out.println("4. Return book");
			System.out.println("5. View all on loan books ");
			System.out.println("6. View all books not on loan");
			System.out.println("7. View by genre ");
			System.out.println("8. View by rating ");
			System.out.println("9. Exit");
			System.out.println("\nEnter option .....");
			option =  scanner.nextInt();
			System.out.println();
		} catch(Exception ex){
			// flush / reset the scanner
			scanner.next();
		}
		return option;
	}
	
	
	/**
	 * Displays all the books
	 */
	public static void listAllBooks(){
		System.out.printf("%-30s %-20s %-10s %-10s \n","Title","Author","ID", "On Loan");

		for (Book b : books){
			System.out.printf("%-30s %-20s %-10d %-10b \n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan());
		}
		
	}
	
	/**
	 * Searches each book by author
	 * @param author
	 */
	public static void searchByAuthor(){
		String author = "";
		System.out.println("Enter author ....");
		author = scanner.next();
		
		System.out.printf("%-30s %-20s %-10s %-10s \n","Title","Author","ID","On Loan");
		int booksFound=0;
		for (Book b : books){
			if (b.getAuthor().equals(author)){
				booksFound++;
				System.out.printf("%-30s %-20s %-10d  %-10b \n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan());
			}
		}
		System.out.println("Number of books found "+booksFound);
	}

	/**
	 * Attempts to register a loan of the book 
	 * @param ID
	 */
	public static void loanBook(){
		boolean bookFound=false;
		int ID = 0;
		// get the ID
		System.out.println("Enter ID of book");
		try{
			ID = scanner.nextInt();
		} catch(Exception ex){
			// flush / reset the scanner
			scanner.next();
		}
		// search list for book with ID
		for (Book b : books){
			if (b.getID() == ID ){
				// got the book now check attempt to borrow
				bookFound = true;
				b.loan();
				break;
			}
		}
		if (!bookFound){
			System.out.println("Sorry no book of that ID");
		}
	}
	
	
	/**
	 * Attempts to return a loan of the book 
	 * @param ID
	 */
	public static void returnBook(){
		boolean bookFound=false;
		int ID = 0;
		// get the ID
		System.out.println("Enter ID of book");
		try {
			ID = scanner.nextInt();
		} catch(Exception ex){
			// flush / reset the scanner
			scanner.next();
		}
		// search list for book with ID
		for (Book b : books){
			if (b.getID() == ID ){
				// got the book now check attempt to borrow
				bookFound = true;
				b.loanReturn();
				break;
			}
		}
		if (!bookFound){
			System.out.println("Sorry no book of that ID");
		}
	}
	
	/**
	 * Searches for book by requested genre
	 */
	public static void searchByGenre(){
		String genre = "";
		System.out.println("Enter genre ....");
		genre = scanner.next();
		
		System.out.printf("%-30s %-20s %-10s %-10s %-20s \n","Title","Author","ID","On Loan","Genre");
		int booksFound=0;
		for (Book b : books){
			if (b.getGenre().equals(genre)){
				booksFound++;
				System.out.printf("%-30s %-20s %-10d  %-10b %-20s\n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan(), b.getGenre());
			}
		}
		System.out.println("Number of books found "+booksFound);
	}
	
	/**
	 * Searches for book by requested rating
	 */
	public static void searchByRating(){
		int rating = 0;
		System.out.println("Enter rating 1 - 5 ....");
		rating = scanner.nextInt();
		// you could validate user entry this here..
		System.out.printf("%-30s %-20s %-10s %-10s %-10s \n","Title","Author","ID","On Loan","Rating");
		int booksFound=0;
		for (Book b : books){
			if (b.getRating() == rating){
				booksFound++;
				System.out.printf("%-30s %-20s %-10d  %-10b %-10s\n",b.getTitle(), b.getAuthor(), b.getID(), b.isOnLoan(), b.getRating());
			}
		}
		System.out.println("Number of books found "+booksFound);
	}
}
