/**
 * 
 */
package librarySystemUpdates;

/**
 * Represents a book
 * 
 * @author amcgowan
 *
 */
public class Book {

	/**
	 * The title of the book
	 */
	private String title;

	/**
	 * The book's author
	 */
	private String author;

	/**
	 * The book's ID
	 */
	private int ID;

	/**
	 * Indicates if the book is loaned
	 */
	private boolean onLoan;
	
	
	/**
	 * The genre of the book
	 */
	private String genre;

	/**
	 * The book's rating
	 */
	private int rating;
	
	
	/**
	 * default constructor - no args
	 */
	public Book() {

	}

	/**
	 * Construct with args
	 * @param title
	 * @param author
	 * @param ID
	 * @param genre
	 * @param rating
	 */
	public Book(String title, String author, int ID, String genre, int rating) {
		this.setTitle(title);
		this.setAuthor(author);
		this.setID(ID);
		this.setOnLoan(false);
		this.setGenre(genre);
		this.setRating(rating);
	}

	/**
	 * Gets the title of the book
	 * 
	 * @return the title
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * Sets the title of the book
	 * 
	 * @param title
	 *            the title to set
	 */
	public void setTitle(String title) {
		this.title = title;
	}

	/**
	 * Gets the author
	 * 
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Sets the author
	 * 
	 * @param author
	 *            the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * Gets the Book ID
	 * 
	 * @return the id
	 */
	public int getID() {
		return ID;
	}

	/**
	 * Sets the ID of the book
	 * 
	 * @param ID
	 *            the ID to set
	 */
	public void setID(int ID) {
		this.ID = ID;
	}

	/**
	 * Check the on loan status of the book
	 * 
	 * @return the onLoan
	 */
	public boolean isOnLoan() {
		return onLoan;
	}

	/**
	 * Directly sets the book as loan on or returned
	 * 
	 * @param onLoan
	 *            the onLoan to set
	 */
	private void setOnLoan(boolean onLoan) {
		this.onLoan = onLoan;
	}

	/**
	 * Sets the book loan status
	 */
	public void loan() {
		if (this.onLoan) {
			System.out.println("Sorry book already on loan");
		} else {
			this.onLoan = true;
			System.out.println("Book now loaned.  Thank you");
		}
	}

	/**
	 * Registers the book return in the system.
	 */
	public void loanReturn() {
		if (this.onLoan) {
			System.out.println("Book returned.  Thank you");
			this.onLoan = false;
		} else {
			System.out.println("Error : Book not on loan.");
		}
	}

	/**
	 * Gets the book's genre
	 * @return
	 */
	public String getGenre() {
		return genre;
	}

	
	/**
	 * Set the book's genre 
	 * @param genre
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}

	/**
	 * Gets the book's rating
	 * @return the rating
	 */
	public int getRating() {
		return rating;
	}

	/**
	 * Sets the books rating
	 * @param rating the rating to set (limited 1 - 5)
	 */
	public void setRating(int rating) {
		// validate before setting
		if (rating>=1 && rating <=5){
			this.rating = rating;
		} else {
			System.out.println("Problem setting rating");
			// defaulting to 0
			this.rating=0;
		}
	}
}
