package uk.ac.qub.week1p;

public class Part3p4 {

	/**
	 * Main method for Part 3.4 for practical 1.
	 * @param args
	 */
	public static void main(String[] args) {

		int yearOfBirth, yearWhenITurn21, yearWhenITurn40, yearWhenIRetireAt60;
		
		yearOfBirth = 1980;
		yearWhenITurn21 = yearOfBirth + 21;
		yearWhenITurn40 = yearOfBirth + 40;
		yearWhenIRetireAt60 = yearOfBirth + 65;
		
		System.out.println("Birth    : "+yearOfBirth);
		System.out.println("Turn 21  : "+yearWhenITurn21);
		System.out.println("Turn 40  : "+yearWhenITurn40);
		System.out.println("Retire   : "+yearWhenIRetireAt60);
	}

	
}
