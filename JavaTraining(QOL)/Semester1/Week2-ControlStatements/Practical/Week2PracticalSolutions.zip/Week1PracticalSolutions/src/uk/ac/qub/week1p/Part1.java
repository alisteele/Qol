package uk.ac.qub.week1p;

public class Part1 {

	/**
	 * Main method for Part 1 for practical 1b.
	 * @param args
	 */
	public static void main(String[] args) {
		
		// outputting Hello world !  I am alive.
		System.out.println("Hello world !  I am alive.");
		
		// outputting on two lines
		System.out.println("Hello world !  I am alive.");
		System.out.println("I can write on two lines!");
		
		// outputting on two lines with a break
		System.out.println("Hello world !  I am alive.\n");
		System.out.println("I can write on two lines!");
		
		// Happy Christmas message!
		System.out.println("\t  Happy Christmas\n");
		System.out.println("\t \t   *");
		System.out.println("\t \t  ***");
		System.out.println("\t \t *****");
		System.out.println("\t \t*******");
		
		// same using printf (note the %25s etc right justifies the characters by the stated numbers of spaces)
		System.out.printf("%25s \n","Happy Christmas");
		System.out.printf("%20s \n","*");
		System.out.printf("%21s \n","***");
		System.out.printf("%22s \n","*****");
		System.out.printf("%23s \n","*******");
		
		
		// Macbeth with tab character 
		System.out.println("First Witch  \t\t When shall we three meet again? ");
		System.out.println("             \t\t In thunder, lightning, or in rain? \n");

		System.out.println("Second Witch \t\t When the hurlyburly's done,");
		System.out.println("             \t\t When the battle's lost and won. \n");
		
		System.out.println("Third Witch  \t\t That will be ere the set of sun. \n");
		
		
		// Macbeth... with printf (note %-24s left justifies the characters)
		System.out.printf("%-24s %-40s \n","First Witch" , "When shall we three meet again? ");
		System.out.printf("%-24s %-40s \n\n" ,"" ,"In thunder, lightning, or in rain?");

		System.out.printf("%-24s %-40s \n","Second Witch" , "When the hurlyburly's done,");
		System.out.printf("%-24s %-40s \n\n" ,"" ,"When the battle's lost and won.");
		
		System.out.printf("%-24s %-40s \n","Third Witch" , "That will be ere the set of sun.");
	}

}
