package uk.ac.qub.week1p;

public class Part3p3 {

	/**
	 * Main method for Part 3.3 for practical 1.
	 * @param args
	 */
	public static void main(String[] args) {

        // declaring variables
		int number1, number2;
		number1 = 3;
		number2 = 10;
		// checking relationships between numbers - using relation operators
		if (number1>number2){
			System.out.println("The biggest number is "+number1);
		}
		if (number1<number2){
			System.out.println("The biggest number is "+number2);
		}
		if (number1==number2){
			System.out.println("Both numbers are the same");
		}

	}

}
