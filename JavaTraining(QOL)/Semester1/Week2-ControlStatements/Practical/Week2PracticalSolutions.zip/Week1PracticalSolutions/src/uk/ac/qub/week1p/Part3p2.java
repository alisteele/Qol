package uk.ac.qub.week1p;

public class Part3p2 {

	/**
	 * Main method for Part 3.2 for practical 1.
	 * Programs calculates the area of a circle
	 * @param args
	 */
	public static void main(String[] args) {

        // declaring variables
		int radius;
		double area;
		
		radius = 9;
		
		// calculate the area
		area = 3.142 * radius;
		
		// output result
		System.out.printf("Area is : %.2f",area);
		
	}

}
