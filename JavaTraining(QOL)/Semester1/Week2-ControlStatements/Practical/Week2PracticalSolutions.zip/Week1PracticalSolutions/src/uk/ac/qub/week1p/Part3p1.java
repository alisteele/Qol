package uk.ac.qub.week1p;

public class Part3p1 {

	/**
	 * Main method for Part 3.1 for practical 1.
	 * Programs calculates the area of a square
	 * @param args
	 */
	public static void main(String[] args) {

        // declaring variables
		int length, area;
		length = 6;

		// calculate the area
		area = length * length;
		
		// output result
		System.out.println("Area is : "+area);
	}

}
