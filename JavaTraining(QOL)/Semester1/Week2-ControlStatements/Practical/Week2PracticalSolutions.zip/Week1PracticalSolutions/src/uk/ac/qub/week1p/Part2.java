package uk.ac.qub.week1p;

public class Part2 {

	/**
	 * Main method for Part 2 for practical 1b.
	 * @param args
	 */
	public static void main(String[] args) {


		// declare a string
		String input;
		input = "Aidan McGowan";
		// get the  number of characters etc
		System.out.println("The input String : "+input);
		System.out.println("The number of characters in the string : "+input.length());		
		System.out.printf("The first character in the string is %s and the second character in the string is %s ",input.charAt(2),input.charAt(1));
		System.out.println("Number of letters : "+input.toUpperCase());
		System.out.println("The string with the letter a replaced with % is : "+input.replace('a', '%'));
		System.out.println("The character �n�  first occurs in position : "+input.indexOf('n'));
		
		
	}

}
