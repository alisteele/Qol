package uk.ac.qub.week3p;

import java.util.Scanner;

/**
 * Part 2 of practical 2.
 * @author amcgowan
 *
 */
public class Part2 {

	// constants to store the voting age values
	public static final int VOTING_AGE_AUSTRIA = 16;
	public static final int VOTING_AGE_UK = 18;
	public static final int VOTING_AGE_SINGAPORE = 21;
	
	/**
	 * Main method for voting calculator.
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		// set up scanner
		Scanner scanner = new Scanner(System.in);

		// vars for age and country (user input)
		int age, country;

		// draw the menu
		System.out.println("Voting age calculator");
		System.out.println("_______________________________________");
		System.out.println("1. Austria");
		System.out.println("2. Singapore");
		System.out.println("3. UK");
		System.out.println("Select your country ...");

		// read in  and store response
		country = scanner.nextInt();

		System.out.println("\nPlease enter your age : ");
		// read in  and store response
		age = scanner.nextInt();

        // check the country and then check the appropriate age
		switch (country) {
			case 1: 
				if (age >= VOTING_AGE_AUSTRIA) {
					System.out.println("You are old enough to vote in Austria");
				} else {
					System.out.println("You are not old enough to vote in Austria. You can vote in "+(VOTING_AGE_AUSTRIA-age) +" year(s)");
				}
				break;
			case 2: 
				if (age >= VOTING_AGE_SINGAPORE) {
					System.out.println("You are old enough to vote in Singapore");
				} else {
					System.out.println("You are not old enough to vote in Singapore.  You can vote in "+(VOTING_AGE_SINGAPORE-age) +" year(s)");
				}
				break;
			case 3: 
				if (age >= VOTING_AGE_UK) {
					System.out.println("You are old enough to vote in the UK");
				} else {
					System.out.println("You are not old enough to vote in the UK.  You can vote in "+(VOTING_AGE_UK-age) +" year(s)");
				}
				break;
			default :
				System.out.println("Sorry.  Unknown country");
		}
		System.out.println("Thank you for using the program.");

		// close the resource.
		scanner.close();
	}

}
