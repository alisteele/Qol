package solutions;

import java.util.Random;

/** 
 * Java simple calculator class
 * @author amcgowan
 */
public class Calculator {

	private int memory = 0;

	/**
	 * @return the memory
	 */
	public int getMemory() {
		return memory;
	}

	/**
	 * @param memory the memory to set
	 */
	public void setMemory(int memory) {
		this.memory = memory;
	}
	
	/**
	 * Add two numbers
	 * @param num1
	 * @param num2
	 */
	public void addNumbers(int num1, int num2){
		System.out.println(num1+num2);
	}
	
	/**
	 * Subtracts two numbers
	 * @param num1
	 * @param num2
	 */
	public void subtractNumbers(int num1, int num2){
		System.out.println(num1-num2);
	}
	
	/**
	 * Multiplies two numbers
	 * @param num1
	 * @param num2
	 */
	public void multiplyNumbers(int num1, int num2){
		System.out.println(num1*num2);
	}
	
	/**
	 * Divides two numbers
	 * @param num1
	 * @param num2
	 */
	public void divideNumbers(int num1, int num2){
		System.out.println(num1-num2);
	}
	
	/**
	 * Finds the square root of a given number
	 * @param num1
	 */
	public void squareRoot(int num1){
		System.out.println(Math.sqrt(num1));
	}
	
	/**
	 * Outputs a random number
	 */
	public void randonNumber(){
		Random random = new Random();
		System.out.println(random.nextInt());
	}
	
	public void addToMemory(int num){
		this.setMemory(num);
	}
	
	/**
	 * Recalls the number in memory 
	 */
	public void recallFromMemory(){
		System.out.println(this.getMemory());
	}
	
	/**
	 * resets memory to zero
	 */
	public void clearMemory(){
		this.setMemory(0);
		System.out.println("Memory cleared");
	}
	
}
