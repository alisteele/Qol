package P3;

/**
 * Stub class represents sending an email - will be replaced when actual class is delivered
 * @author amcgowan
 *
 */
public class EmailControl {

	/**
	 * Stub method - returns true by default
	 * @param from
	 * @param to
	 * @param subject
	 * @param message
	 * @return
	 */
	public boolean sendMessage(String from, String to, String subject, String message){
		return true;
	}
	
}
