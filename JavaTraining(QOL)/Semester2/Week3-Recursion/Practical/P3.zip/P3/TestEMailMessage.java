package P3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestEMailMessage {

	// test data
	String from;
	String to;
	String subject;
	String message;

	String invalidFrom;
	String invalidTo;
	String invalidSubject;
	String invalidMessage;

	@Before
	public void setUp() throws Exception {
		from = "aidan.mcgowan@qub.ac.uk";
		to = "george.best@footballer.com";
		subject = "Subject";
		message = "Message info here";
	}

	/**
	 * Tests the constructor - valid values
	 */
	@Test
	public void testEMailMessageStringStringStringString() {
		boolean status = false;
		// create message with args
		EMailMessage em = new EMailMessage(from, to, subject, message);

		// now test each one
		if ((em.getTo().equals(to)) && (em.getFrom().equals(from))
				&& (em.getSubject().equals(subject))
				&& (em.getMessage().equals(message))) {
			status = true;
		}

		assertTrue(status);
	}

	/**
	 * Tests the constructor - invalid values (FROM)
	 */
	@Test
	public void testEMailMessageStringStringStringStringInValidFrom() {
		boolean status = false;
		invalidFrom = "@qub.ac.uk";
		// create message with args
		EMailMessage em = new EMailMessage(invalidFrom, to, subject, message);

		// now test each one
		if ((em.getTo().equals(to)) && (em.getFrom() == null)
				&& (em.getSubject().equals(subject))
				&& (em.getMessage().equals(message))) {
			status = true;
		}

		assertTrue(status);
	}

	/**
	 * Tests the constructor - invalid values (TO)
	 */
	@Test
	public void testEMailMessageStringStringStringStringInValidTo() {
		boolean status = false;
		invalidTo = "@qub.ac.uk";
		// create message with args
		EMailMessage em = new EMailMessage(from, invalidTo, subject, message);

		// now test each one
		if ((em.getFrom().equals(from)) && (em.getTo() == null)
				&& (em.getSubject().equals(subject))
				&& (em.getMessage().equals(message))) {
			status = true;
		}

		assertTrue(status);
	}

	@Test
	public void testEmailSetTo() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setTo(to);
		System.out.println("Email TO ");
		if (em.getTo().equals(to)){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	
	@Test
	public void testEmailSetToInvalid() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setTo(invalidTo);
		if (em.getTo()==null){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	
	@Test
	public void testSubjectSetSubject() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setSubject(subject);
		if (em.getSubject().equals(subject)){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	
	@Test
	public void testSubjectSetInvalidSubject() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setSubject(invalidSubject);
		if (em.getSubject()==null){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	
	
	@Test
	public void testSubjectSetMessage() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setMessage(message);
		if (em.getMessage().equals(message)){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	
	@Test
	public void testSubjectSetInvalidMessage() {
		// create message with args
		EMailMessage em = new EMailMessage();
		em.setMessage(invalidMessage);
		if (em.getMessage()==null){
			assertTrue(true);
		} else {
			assertTrue(false);
		}
	}
	

}
