package P3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class TestMonthTranslator {

	@Before
	public void setUp() throws Exception {
	}

	@Test
	public void testMonthJan() {
		assertEquals(MonthTranslator.month(1), "Jan");
	}
	
	@Test
	public void testMonthFeb() {
		assertEquals(MonthTranslator.month(2), "Feb");
	}
	
	@Test
	public void testMonthMar() {
		assertEquals(MonthTranslator.month(3), "Mar");
	}
	
	@Test
	public void testMonthApr() {
		assertEquals(MonthTranslator.month(4), "Apr");
	}
	
	@Test
	public void testMonthMay() {
		assertEquals(MonthTranslator.month(5), "May");
	}
	
	
	
	@Test
	public void testMonthJun() {
		assertEquals(MonthTranslator.month(6), "Jun");
	}
	
	@Test
	public void testMonthJul() {
		assertEquals(MonthTranslator.month(7), "Jul");
	}
	
	@Test
	public void testMonthAug() {
		assertEquals(MonthTranslator.month(8), "Aug");
	}
	
	@Test
	public void testMonthSep() {
		assertEquals(MonthTranslator.month(9), "Sep");
	}
	
	@Test
	public void testMonthOct() {
		assertEquals(MonthTranslator.month(10), "Oct");
	}
	
	@Test
	public void testMonthNov() {
		assertEquals(MonthTranslator.month(11), "Nov");
	}
	
	@Test
	public void testMonthDec() {
		assertEquals(MonthTranslator.month(12), "Dec");
	}
	
	@Test (expected=NumberFormatException.class )
	public void testMonthUnknown() {
		assertEquals(MonthTranslator.month(13), "0");
	}
	

	
}
