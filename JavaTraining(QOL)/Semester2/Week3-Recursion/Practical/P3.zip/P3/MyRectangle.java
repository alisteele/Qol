package P3;

/**
 * Class represents a Rectangle
 * @author Aidan McGowan
 */
public class MyRectangle implements IMyShape {

	/**
	 * The shape length
	 */
	private double length;
	
	/**
	 * Rectangle breadth
	 */
	private double breadth;
	
	/**
	 * The shape's name
	 */
	private String shapeName;
	
	
	/**
	 * Default constructor
	 */
	public MyRectangle(){
	}
	
	/**
	 * Constuctor with parameter
	 * @param length
	 * @param breadth
	 */
	public MyRectangle(double length, double breadth){
		this.length = length;
		this.breadth = breadth;
		this.shapeName = "Rectangle";
	}
	
	/**
	 * Calculates the area of the rectangle 
	 * @return the area
	 */
	public double calculateArea() {
		double area = length * breadth;
		return area;
	}

	/**
	 * Calculates the perimeter of the rectangle 
	 * @return the perimeter
	 */
	public double calculatePerimeter() {
		double perimeter = 2 * (length + breadth);
		return perimeter;
	}
	
	/**
	 * Gets the name of the shape
	 * @return the name of the shape
	 */
	public String getShapeName() {
		return shapeName;
	}
	
}
