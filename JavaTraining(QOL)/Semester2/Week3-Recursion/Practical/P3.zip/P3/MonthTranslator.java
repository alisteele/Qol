package P3;

/**
 * Class that translates a number value 1-12 into the string value for the month
 * @author amcgowan
 */
public class MonthTranslator {

	/**
	 * Method accepts an int value which it then translates to a string value of the month
	 * eg. given 8 will return Aug
	 * @param num - the number of the month limited to 1-12
	 * @return the month as a string (3 chars eg Jan, Feb etc)
	 * @throws NumberFormatException and number outside 1-12 (inclusive)
	 */
	public static String month(int num) throws NumberFormatException  {
		String monthAsString = null;
		
		switch (num){
		case 1:
			monthAsString = "Jan";
			break;
		case 2:
			monthAsString = "Feb";
			break;
		case 3:
			monthAsString = "Mar";
			break;
		case 4:
			monthAsString = "Apr";
			break;
		case 5:
			monthAsString = "May";
			break;
		case 6:
			monthAsString = "Jun";
			break;
		case 7:
			monthAsString = "Jul";
			break;
		case 8:
			monthAsString = "Aug";
			break;
		case 9:
			monthAsString = "Sep";
			break;
		case 10:
			monthAsString = "Oct";
			break;
		case 11:
			monthAsString = "Nov";
			break;
		case 12:
			monthAsString = "Dec";
			break;
		default:
			throw new NumberFormatException();
			
		}
		return monthAsString;
		
	}
	
}
