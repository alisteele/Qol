package P3;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class CaesarCipherTest {

	@Before
	public void setUp() throws Exception {
		
	}

	@Test
	public void testEncrypt() {
		String encryptStr = "ABCDE";
		int key = 1;
		String expected = "BCDEF";
		
		assertEquals(expected, CaesarCipher.encrypt(encryptStr, key));
	}

	@Test
	public void testDecrypt() {
		String decryptStr = "BCDEF";
		int key = 1;
		String expected = "ABCDE";
		
		assertEquals(expected, CaesarCipher.decrypt(decryptStr, key));
	}

}
