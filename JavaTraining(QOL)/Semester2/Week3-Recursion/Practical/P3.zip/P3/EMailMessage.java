package P3;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * EMail message class- Represents an email message
 * 
 * @author amcgowan
 * 
 */
public class EMailMessage {

	private String from;
	private String to;
	private String message;
	private String subject;

	/**
	 * Regex for a valid email format text@text
	 */
	public static final Pattern VALID_EMAIL_ADDRESS_REGEX = Pattern.compile(
			"[A-Z0-9]+@[A-Z0-9]", Pattern.CASE_INSENSITIVE);

	/**
	 * Regex for a valid subject. Upper case then 1 - 19 characters
	 */
	public static final Pattern VALID_SUBJECT_REGEX = Pattern
			.compile("^[A-Z].{1,19}$");

	/**
	 * Regex for a valid Message. 1 - 255 characters
	 */
	public static final Pattern VALID_MESSAGE_REGEX = Pattern
			.compile("^.{1,255}$");
	
	/**
	 * Default constructor
	 */
	public EMailMessage() {

	}

	/**
	 * Constructor with args. Takes the message FROM, TO, SUBJECT and MESSAGE
	 * details
	 * 
	 * @param from
	 *            (format text@text )
	 * @param to
	 *            (format text@text )
	 * @param message
	 *            (Upper case then 1 - 19 characters)
	 * @param subject
	 *            (1 - 255 characters)
	 */
	public EMailMessage(String from, String to, String subject, String message) {
		this.setTo(to);
		this.setFrom(from);
		this.setSubject(subject);
		this.setMessage(message);
	}

	/**
	 * Sends the message
	 */
	public void sendMessage() {

		EmailControl ec = new EmailControl();
		ec.sendMessage(this.from, this.to, this.subject, this.message);

	}

	/**
	 * Get the From details
	 * 
	 * @return
	 */
	public String getFrom() {
		return from;
	}

	/**
	 * Sets the From details
	 * 
	 * @param from
	 */
	public void setFrom(String from) {
		if (this.checkEmailAddress(from)) {
			this.from = from;
		} else {
			System.out.println("Invalid FROM address");
		}
	}

	/**
	 * Gets the TO details
	 * 
	 * @return
	 */
	public String getTo() {
		return to;
	}

	/**
	 * Sets the TO details
	 * 
	 * @param to
	 */
	public void setTo(String to) {
		if (this.checkEmailAddress(to)) {
			this.to = to;
		} else {
			System.out.println("Invalid TO address");
		}
	}

	/**
	 * Gets the message
	 * 
	 * @return
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * Sets the message
	 * 
	 * @param message
	 */
	public void setMessage(String message) {
		if (this.checkMessage(message)) {
			this.message = message;
		} else {
			System.out.println("Invalid SET format");
		}
	}

	/**
	 * Gets the subject
	 * 
	 * @return
	 */
	public String getSubject() {
		return subject;
	}

	/**
	 * sets the subject
	 * 
	 * @param subject
	 */
	public void setSubject(String subject) {
		if (this.checkSubject(subject)) {
			this.subject = subject;
		} else {
			System.out.println("Invalid SUBJECT format !");
		}
	}

	/**
	 * Checks the email address per allowable format
	 * 
	 * @param to
	 * @return true if OK
	 */
	private boolean checkEmailAddress(String to) {
		boolean pass = false;
		if (to != null) {
			Matcher matcher = VALID_EMAIL_ADDRESS_REGEX.matcher(to);
			pass = matcher.find();
		}
		return pass;
	}

	/**
	 * Checks the subject as per format
	 * 
	 * @param subject
	 * @return true if OK
	 */
	private boolean checkSubject(String subject) {
		boolean pass = false;
		if (subject != null) {
			Matcher matcher = VALID_SUBJECT_REGEX.matcher(subject);
			pass=matcher.find();
		}
		return pass;

	}

	/**
	 * Checks the message as per format
	 * 
	 * @param message
	 * @return true if OK
	 */
	private boolean checkMessage(String message) {
		boolean pass = false;
		if (message != null) {
			Matcher matcher = VALID_MESSAGE_REGEX.matcher(message);
			pass=matcher.find();
		}
		return pass;
	}

	
}
