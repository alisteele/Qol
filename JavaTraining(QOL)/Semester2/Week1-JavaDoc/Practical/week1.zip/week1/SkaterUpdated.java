package week1;

import java.util.Arrays;

/**
 * Class represents a Skater in a competition
 * 
 * @author amcgowan
 */
public class SkaterUpdated {

	private final static int SCORES_MAX = 7;
	
	private final static int UPPER_RANGE = 10;
	
	private final static int LOWER_RANGE = 0;

	private double[] scores = new double[SCORES_MAX];
	private String firstName;
	private String lastName;

	/**
	 * Default constructor
	 */
	public SkaterUpdated() {
	}

	/**
	 * Constuctor with exams
	 * 
	 * @param firstName
	 * @param lastName
	 * @param score
	 */
	public SkaterUpdated(String firstName, String lastName, double[] score) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.setScore(score);
	}

	/**
	 * Calculates the overall score. Discards the lowest and highest score
	 * before working out the average
	 * 
	 * @return the average score
	 */
	public double calculateOverallScore() {
		double total = 0;
		double minimum = scores[0];
		double maximum = scores[0];
		double overallScore = 0;

		for (int loop = 0; loop < scores.length; loop++) {
			total += scores[loop];
			// get the min score
			if (scores[loop] < minimum) {
				minimum = scores[loop];
			}
			// get the max score
			if (scores[loop] > maximum) {
				maximum = scores[loop];
			}
		}
		// discard the min and max score
		total = total - minimum - maximum;
		// calculate the average
		overallScore = total / (SCORES_MAX-2);

		return overallScore;
	}

	public double[] getScore() {
		return scores;
	}

	public void setScore(double[] scores) {

		boolean validScores = true;

		// first check numbers of scores
		if (scores.length == SCORES_MAX) {

			// validation check
			for (double score : scores) {
				if (!(score >= LOWER_RANGE && score <= UPPER_RANGE)) {
					// problem with the value
					System.out.println("Attempt to set score outside range (defaulting to zero)");

					// set all to 0;
					Arrays.fill(this.scores, 0);
					// not going any further
					validScores = false;
					break;
				}
			}

			// only set to passed values if all values are valid
			if (validScores) {
				this.scores = scores;
			}
		} else {
			// incorrect number of scores  
			System.out.println("Incorrect number of scores");
			
		}

	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * Ad hoc test of the class
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		SkaterUpdated aSkater = new SkaterUpdated();
		aSkater.setFirstName("A");
		aSkater.setLastName("Skater");
		double[] scores = { 4.0, 5.0, 3.0, 6.0, 8.0, 4.0, 10.0 };
		aSkater.setScore(scores);
		System.out.printf("Name : %s %s", aSkater.getFirstName(),
				aSkater.getLastName());
		System.out.println();
		System.out.printf("Score average : %.2f",
				aSkater.calculateOverallScore());
	}

}
