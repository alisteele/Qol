package week1;

public class Palindrome {
	/**
	 * Checks for Palindrome word (case sensitive)
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPalindrome(String str) {

		// convert string str to an array of characters
		char[] c = new char[str.length()];
		for (int loop = 0; loop < str.length(); loop++) {
			c[loop] = str.charAt(loop);
		}

		// test if it is a palindrome
		for (int loop = 0, j = str.length() - 1; loop < j; loop++, j--) {
			if (c[loop] != c[j]) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks for Palindrome word - but ignores case
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPalindromeIgnoreCase(String str) {

		// convert string str to an array of characters
		char[] c = new char[str.length()];
		for (int loop = 0; loop < str.length(); loop++) {
			c[loop] = str.charAt(loop);
		}

		// test if it is a palindrome
		for (int loop = 0, j = str.length() - 1; loop < j; loop++, j--) {
			if (Character.toLowerCase(c[loop]) != Character.toLowerCase(c[j])) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Checks if a phrase is a Palindrome
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isPalindromePhrase(String str) {

		// remove the spaces
		String parsedString = str.replaceAll("\\s", "");

		// convert string to an array of characters
		char[] c = new char[parsedString.length()];
		for (int loop = 0; loop < parsedString.length(); loop++) {
			c[loop] = parsedString.charAt(loop);
		}

		// test if it is a palindrome
		for (int loop = 0, j = c.length - 1; loop < j; loop++, j--) {
			if (c[loop] != c[j]) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Ad hoc test for the methods
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("isPalindrome : " + isPalindrome("Tester"));
		System.out.println("isPalindrome : " + isPalindrome("NoxiNNixoN"));

		System.out.println("isPalindromeIgnoreCase : "
				+ isPalindromeIgnoreCase("NoxiNiXoN"));

		System.out.println("isPalindromePhrase : "
				+ isPalindromePhrase("no x i nixon"));

	}

}
