package week1;

/**
 * Class represents a Skater in a competition 
 * @author amcgowan
 */
public class Skater {

	private final static int SCORES_MAX = 5; 
	
	private double[] scores = new double[SCORES_MAX];
	private String firstName;
	private String lastName;
	
	
	/**
	 * Default constructor
	 */
	public Skater(){
	}
	
	/**
	 * Constuctor with scores
	 * @param firstName
	 * @param lastName
	 * @param score
	 */
	public Skater(String firstName, String lastName, double[] scores){
		this.firstName = firstName;
		this.lastName = lastName;
		this.scores = scores;
	}
	
	/**
	 * Calculates the overall score. Discards the lowest and highest score 
	 * before working out the average
	 * @return the average score
	 */
	public double calculateOverallScore() {
		double total = 0;
		double minimum = scores[0];
		double maximum = scores[0];
		double overallScore=0;
		
		for (int loop = 0; loop < scores.length; loop++) {
			total += scores[loop];
			// get the min score
			if (scores[loop] < minimum){
				minimum = scores[loop];
			}
			// get the max score
			if (scores[loop] > maximum) {
				maximum = scores[loop];
			}
		}
		// discard the min and max score 
		total = total - minimum - maximum;
		// calculate the average
		overallScore = total / 3;

		return overallScore;
	}

	
	public double[] getScores() {
		return scores;
	}


	public void setScores(double[] scores) {
		this.scores = scores;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	
	/**
	 * Ad hoc test of the class
	 * @param args
	 */
	public static void main(String[] args) {
		
		Skater aSkater = new Skater();
		aSkater.setFirstName("Jane");
		aSkater.setLastName("Spinner");
		double[] scores = {4.0,5.0,3.0,6.0,8.0};
		aSkater.setScores(scores);
		System.out.printf("Name : %s %s",aSkater.getFirstName(), aSkater.getLastName());
		System.out.printf("Score average : %.2f",aSkater.calculateOverallScore());
	}

}
