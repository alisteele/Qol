package P2;

import java.util.Arrays;

/**
 * Class reads command line arguments and converts to Integers (if appropriate)
 * then sorts and outputs to screen
 * 
 * @author amcgowan
 * 
 */
public class CommandLineReader {

	public static void main(String[] args) {
 
		int pointer = 0;
		// create Integer array for the possible values (note : arrays can't change in size so a better
		// solution would be an arraylist - lesson coming soon)
		Integer[] wrapperIntArray = new Integer[args.length];

		// check if the string can be converted to a number
		for (int loop = 0; loop < args.length; loop++) {
			if (allowableValue(args[loop])) {
				System.out.println("Adding "+args[loop]);
				wrapperIntArray[pointer] = new Integer(args[loop]);
				// keep record of non null and add in values in sequence to the Integer array
				pointer++;
			} else {
				System.out.println("Sorry entry value(s) incorrect");
			}
		}

		// as we used an array to store the numbers (if any were passed) there
		// may be some null values (set as default)
		// so now we create an new Integer array without the null values which if any 
		// exist will be at the end of wrapperIntArray 
		Integer[] parsedIntArray = Arrays.copyOfRange(wrapperIntArray, 0, --pointer);
		
		// now sort and print
		if (parsedIntArray.length > 0) {
			// sort
			Arrays.sort(parsedIntArray);

			// output to screen
			System.out.println("Output sorted : "
					+ Arrays.toString(parsedIntArray));
		} else {
			System.out.println("No valid values passed");
		}

	}

	/**
	 * Check if valid value i.e. string versions of 0,1,2,3,4,5,6,7,8,9
	 * 
	 * @param value
	 * @return
	 */
	public static boolean allowableValue(String value) {
		boolean valid = false;
		switch (value) {
		case "0":
		case "1":
		case "2":
		case "3":
		case "4":
		case "5":
		case "6":
		case "7":
		case "8":
		case "9":
			valid = true;
			break;
		default:
			valid = false;
		}
		return valid;
	}

	
}
