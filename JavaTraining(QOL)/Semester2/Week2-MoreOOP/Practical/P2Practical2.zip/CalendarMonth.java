package P2;

/**
 * Class outputs a monthly calendar for a selected month
 * @author amcgowan
 *
 */
public class CalendarMonth {

	/**
	 * The month
	 */
	private int month;
	
	/**
	 * The start day of the month. 1 = Sunday 7 = Saturday 
	 */
	private int startDay;
	
	/**
	 * Indicates if the year is a leap year
	 */
	private boolean leapYear;

	/**
	 * Used for formatting between days output 
	 */
	private static final String THREE_SPACE_BETWEEN_DAYS = "   ";
	
	/**
	 * Used for formatting between days output 
	 */
	private static final String TWO_SPACE_BETWEEN_DAYS = "  ";
	
	/**
	 * Used for formatting between days output 
	 */
	private static final String ONE_SPACE_BETWEEN_DAYS = " ";

	
	/**
	 * Default constructor
	 */
	public CalendarMonth() {

	}

	/**
	 * Constructs the class with preset values
	 * @param month 1-12
	 * @param startDay  1-7 (1 is a Sunday)
	 * @param leapYear - set to true if a leap year
	 */
	public CalendarMonth(int month, int startDay, boolean leapYear) {
		this.month = month;
		this.startDay = startDay;
		this.setLeapYear(leapYear);
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getStartDay() {
		return startDay;
	}

	public void setStartDay(int startDay) {
		this.startDay = startDay;
	}
	
	public boolean isLeapYear() {
		return leapYear;
	}

	public void setLeapYear(boolean leapYear) {
		this.leapYear = leapYear;
	}

	/**
	 * Displays on screen the  view the selected month
	 * FEBRUARY
	 * S  M  T  W  T  F  S
	 * 1  2  3  4  5  6
	 * 7  8  9  10 11 12 13
	 * 14 15 16 17 18 19 20
	 * 21 22 23 24 25 26 27
	 * 28
	 */
	public void show() {

		// line break
		System.out.println();
		
		// show the month name
		System.out.println(this.determineMonthName());

		// output header days
		System.out.println();
		System.out.println("S  M  T  W  T  F  S");

		// keeping track of outputted day
		int count = 0;

		// print leading blanks before the first day
		for (int loop = 1; loop < this.startDay; loop++) {
			System.out.print(THREE_SPACE_BETWEEN_DAYS);
			count++;
		}

		// now print the days row
		for (int loop = 1; loop <= this.determineNumberOfDays(); loop++) {
			// update the day tracker
			count++;

			// check if this is a Saturday
			if (count % 7 == 0) {
				// on a saturday so print number and wrap
				System.out.println(loop); 
			} else {
				// otherwise print the number but need only one space between double digits
				if (loop >= 10) {
					System.out.print(loop + ONE_SPACE_BETWEEN_DAYS);
				} else {
					System.out.print(loop + TWO_SPACE_BETWEEN_DAYS);
				}
			}
		}
	}

	/**
	 * Given the month as number determine the number of days in the month
	 * @return
	 */
	public int determineNumberOfDays() {
		int numberOfDays = 0;
		switch (this.month) {
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			numberOfDays = 31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			numberOfDays = 30;
			break;
		case 2:
			if (this.leapYear) {
				numberOfDays = 29;
			} else {
				numberOfDays = 28;
			}
			break;
		default:
			System.out.println("Problem with month");
			numberOfDays = 0;
		}
		return numberOfDays;
	}

	/**
	 * Given the month as number determine name of the month
	 * @return
	 */
	public String determineMonthName() {

		String monthName = null;

		switch (this.month) {
		case 1:
			monthName = "JANUARY";
			break;
		case 2:
			monthName = "FEBRUARY";
			break;
		case 3:
			monthName = "MARCH";
			break;
		case 4:
			monthName = "APRIL";
			break;
		case 5:
			monthName = "MAY";
			break;
		case 6:
			monthName = "JUNE";
			break;
		case 7:
			monthName = "JULY";
			break;
		case 8:
			monthName = "AUGUST";
			break;
		case 9:
			monthName = "SEPTEMBER";
			break;
		case 10:
			monthName = "OCTOBER";
			break;
		case 11:
			monthName = "NOVEMBER";
			break;
		case 12:
			monthName = "DECEMBER";
			break;
		}

		return monthName;

	}

	/**
	 * Ad hoc test for the class
	 * @param args
	 */
	public static void main(String[] args) {
		CalendarMonth feb = new CalendarMonth(2, 2, false);
		feb.show();
		System.out.println();
		
		CalendarMonth febLeap = new CalendarMonth(2, 2, true);
		febLeap.show();
		System.out.println();
		
		CalendarMonth april = new CalendarMonth(4, 4, false);
		april.show();
		System.out.println();
		
		CalendarMonth dec = new CalendarMonth(12, 7, false);
		dec.show();
		System.out.println();

	}
}
