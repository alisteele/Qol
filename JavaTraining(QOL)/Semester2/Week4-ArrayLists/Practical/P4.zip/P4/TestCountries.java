package P4;

public class TestCountries {

	/**
	 * Ad hoc test of the enum type Countries
	 * @param args
	 */
	public static void main(String[] args) {
		
		for (Countries c : Countries.values()) {
			System.out.println(c + "  " + c.getCapital());
		}
	}
}
