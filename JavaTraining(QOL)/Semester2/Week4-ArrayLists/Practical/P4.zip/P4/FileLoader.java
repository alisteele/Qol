package P4;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FileLoader {

	public static void main(String[] args) throws Exception {

		FileLoader fl = new FileLoader();
		List<Integer> numbers = fl.readFile("input.txt");

		Collections.sort(numbers);

		System.out.println(numbers);

		fl.writeFile(numbers, "output.txt");

	}

	public List<Integer> readFile(String fileName) {
		List<Integer> numbers = new ArrayList<>();

		try {
			File f1 = new File(fileName);
			FileReader readFile = new FileReader(f1);
			BufferedReader reader = new BufferedReader(readFile);

			String line = "";
			while ((line = reader.readLine()) != null) {
				int intVar = Integer.parseInt(line);
				numbers.add(intVar);
			}

			reader.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

		return numbers;

	}

	public void writeFile(List<Integer> numbers, String fileName) {

		try {

			File output = new File(fileName);
			if (!output.exists()) {
				output.createNewFile();
			}

			FileWriter fw = new FileWriter(output);
			BufferedWriter bw = new BufferedWriter(fw);

			for (Integer number : numbers) {
				bw.write(number.toString());
				bw.newLine();
			}

			bw.close();

		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
