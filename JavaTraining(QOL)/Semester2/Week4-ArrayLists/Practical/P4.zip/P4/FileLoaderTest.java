package P4;

import java.io.File;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Test;

public class FileLoaderTest {

	private final FileLoader fl = new FileLoader();

	@Test
	public void fileReadTest() {
		List<Integer> expected = Arrays.asList(4, 2, 5, 3, 2, 1);

		List<Integer> actual = fl.readFile("input.txt");

		Assert.assertTrue(expected.equals(actual));

	}

	@Test
	public void fileWriteTest() {
		List<Integer> expected = Arrays.asList(4, 2, 5, 3, 2, 1);
		
		fl.writeFile(expected, "outputTest.txt");
		
		Assert.assertTrue(expected.equals(fl.readFile("outputTest.txt")));

	}
	
	@After
	public void removeTestFiles(){
		File f = new File("outputTest.txt");
		f.delete();
		//Remove files created by the test.
	}

}
