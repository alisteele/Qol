package P4;

public enum Countries {
	// create the list of countries
	ENGLAND("London"), SCOTLAND("Edinburgh"), WALES("Cardiff"), NIRELAND("Belfast"), RIRELAND("Dublin");
	
	private final String capital;
	
	private Countries(String capital) {
		this.capital = capital;
	}
	
	/**
	 * Gets the capital city of the country
	 * @return the capital city
	 */
	 public String getCapital() {
	 	return capital;
	 }


	
	
}
