package P4;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Class to encrypt a file
 * 
 * @author Aidan McGowan
 */
public class FileCipher {

	/**
	 * Default constructor
	 */
	public FileCipher() {
	}

	/**
	 * Encrypts a char
	 * 
	 * @param original
	 * @param key
	 * @return
	 */
	public static char encryptCharacter(char original, int key) {

		char encryptedChar;

		// apply the key to encrypt
		encryptedChar = (char) (original + key);

		return encryptedChar;
	}

	/**
	 * Decrypts the char
	 * 
	 * @param original
	 * @param key
	 * @return the decrypted char
	 */
	public static char decryptCharacter(Character original, int key) {

		char decryptedChar;

		decryptedChar = (char) (original - key);

		return decryptedChar;
	}

	/**
	 * Encrypts all characters in a file param in is the plaintext file param
	 * out is the file to store the encrypted characters key is the encyption
	 * key
	 */
	public void encryptFile(FileReader in, FileWriter out, int key)
			throws IOException {
		System.out.println("Writing to file ...");
		while (true) {
			int next = in.read();
			if (next == -1) {
				return; // end of file
			}
			char c = (char) next;
			out.write(encryptCharacter(c, key));
		}

	}
	
	
	public void decryptFile(FileReader in, FileWriter out, int key)
			throws IOException {
		
		while (true) {
			int next = in.read();
			if (next == -1) {
				return; // end of file
			}
			char c = (char) next;
			out.write(decryptCharacter(c, key));
		}

	}

	/**
	 * Open the input and output files and call the method to perform encryption
	 * 
	 * @param args
	 */

	public static void main(String[] args) {

		FileReader infile = null;
		FileWriter outfile = null;

		int key = 1;

		// create the fileCipher object
		FileCipher fileCipher = new FileCipher();

		// open the input and output files
		try {
			System.out.println("Opening file to read from");
			infile = new FileReader("plainText.txt");
			System.out.println("Opening file to read to");
			outfile = new FileWriter("encryptedText.txt");
		} catch (IOException e) {
			System.out.println("Error opening file");
			System.exit(0);
		}

		// perform encryption and close the input and output files
		try {
			fileCipher.encryptFile(infile, outfile, key);
			infile.close();
			outfile.close();
			System.out.println("Files closed");
		} catch (IOException e) {
			System.out.println("Error processing file");
			System.exit(0);
		}

		// open the input and output files
		try {
			System.out.println("Opening file to read from");
			infile = new FileReader("encryptedText.txt");
			System.out.println("Opening file to read to");
			outfile = new FileWriter("decrypted.txt");
		} catch (IOException e) {
			System.out.println("Error opening file");
			System.exit(0);
		}

		// perform encryption and close the input and output files
		try {
			fileCipher.decryptFile(infile, outfile, key);
			infile.close();
			outfile.close();
			System.out.println("Files closed");
		} catch (IOException e) {
			System.out.println("Error processing file");
			System.exit(0);
		}
	}

}
