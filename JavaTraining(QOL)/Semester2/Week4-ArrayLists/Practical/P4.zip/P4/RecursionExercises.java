package P4;


import java.util.Arrays;

public class RecursionExercises {

	/**
	 * Recursively sums the contents of an array 
	 * @param intArray
	 * @return
	 */
	public static int sumArray(int[] intArray) {
		System.out.println("In with array "+Arrays.toString(intArray));
		if (intArray.length==1) {
			System.out.println("BASE "+intArray[0]);
			return intArray[0];
		} else {
			System.out.println("KEEPING "+intArray[0]);
			return (intArray[0] + sumArray(Arrays.copyOfRange(intArray, 1, intArray.length)));
		}
	}
	
	/**
	 * Recursively prints the contents of a char array in reverse 
	 * @param array
	 */
	public static void recursivePrint(char[] array) {
		if (array.length == 1) {
            // base case
			System.out.printf("%c ",array[0]);
		} else {
			System.out.printf("%c ",array[array.length-1]);
			recursivePrint(Arrays.copyOfRange(array, 0, array.length-1));
        }
    }
	
	
	/**
	 * Recursive method to calculate x to the power of n 
	 * @param number x
	 * @param power n
	 * @return x to the power of n
	 */
	public static int xPowerN(int x,int n) {
		if (n==0) {
			return 1;
		} else {
			return (x * xPowerN(x,n-1));
		}
	}
	
	
	/**
	 * Ad hoc testing of recursive calls
	 * @param args
	 */
	public static void main(String[] args) {

		int[] anArray = {2,4,6,8, 10};
		
		System.out.println("Total : "+sumArray(anArray));
		
		char[] anCharArray = {'N','e','w','Y','o','r','k'};
		recursivePrint(anCharArray);
		System.out.println();
		System.out.println("2 to power of 2 : "+xPowerN(2,2));

	}

}
